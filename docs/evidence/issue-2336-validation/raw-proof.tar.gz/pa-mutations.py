import pathlib,subprocess,tempfile,shutil,json,hashlib,time,xml.etree.ElementTree as ET
P=pathlib.Path(__file__).parent
CALLER=pathlib.Path('/Users/teacher/.codex/automations/pd-workloop-resume/worktrees/pae-2336-ranked-20261010')
PYTHON='/Users/teacher/.codex/automations/imi-merge-verify-closer/work/20261006T2020Z/pae-env/bin/python'
TEST='tests/test_cli_validation_boundaries.py'
def sha(b):return hashlib.sha256(b).hexdigest()
cases=[('test_capital_exception_is_a_failed_result_with_original_details','details={"exception": str(exc)},','details={"exception": "dropped"},','exception detail lost')]
guard='if any((not r.is_valid) and r.severity == "error" for r in results):'
for severity,exitcode in [('warning','None'),('info','None'),('error','1')]:
 cases.append((f'test_validation_only_rejects_errors_without_rejecting_advisories[{severity}-{exitcode}]',guard,'if any(not r.is_valid for r in results):' if severity!='error' else 'if False:', 'validation severity changed exit policy'))
cases.append(('test_validation_forwards_effective_financing_and_simulation_settings','term_months=cfg.financing_term_months,','term_months=None,','effective financing settings were not forwarded'))
output=P/'pa-mutations';output.mkdir(exist_ok=False)
original=(CALLER/'pa_core/cli.py').read_bytes();caller_test=(CALLER/TEST).read_bytes()
receipt={'source_sha256':sha(original),'test_sha256':sha(caller_test),'cases':[]}
with tempfile.TemporaryDirectory(prefix='pa-validation-mutations-') as temp:
 root=pathlib.Path(temp)
 for f in subprocess.check_output(['git','ls-files','-z'],cwd=CALLER).split(b'\0'):
  if f:
   relative=pathlib.Path(f.decode());target=root/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(CALLER/relative,target)
 source=root/'pa_core/cli.py'
 try:
  for i,(name,before,after,marker) in enumerate(cases):
   if original.decode().count(before)!=1:raise RuntimeError('nonunique anchor '+name)
   mutant=original.decode().replace(before,after,1).encode();c={'node':TEST+'::'+name,'before':before,'after':after,'mutant_sha256':sha(mutant),'phases':[]};receipt['cases'].append(c)
   for phase,data,exitcode in [('red',mutant,1),('green',original,0)]:
    source.write_bytes(data)
    for cache in (root/'pa_core/__pycache__').glob('cli.*.pyc'):cache.unlink()
    stem=f'{i:02}-{phase}';junit=output/(stem+'.xml');argv=[PYTHON,'-m','pytest',c['node'],'-q','--junitxml='+str(junit)];started=time.time()
    with (output/(stem+'.txt')).open('w') as o:r=subprocess.run(argv,cwd=root,stdout=o,stderr=subprocess.STDOUT,timeout=90)
    nodes=ET.parse(junit).getroot().findall('.//testcase');valid=r.returncode==exitcode and len(nodes)==1 and nodes[0].get('name')==name and nodes[0].find('error') is None and nodes[0].find('skipped') is None
    if phase=='red':
     failure=nodes[0].find('failure') if nodes else None;valid=valid and failure is not None and failure.get('message','').splitlines()[:1]==['AssertionError: '+marker]
    else:valid=valid and nodes[0].find('failure') is None
    c['phases'].append({'phase':phase,'argv':argv,'cwd':str(root),'exit':r.returncode,'seconds':time.time()-started,'source_sha256':sha(source.read_bytes()),'valid':valid})
    if not valid:raise RuntimeError('invalid phase '+stem+' '+name)
 finally:
  source.write_bytes(original);receipt['isolated_restored_sha256']=sha(source.read_bytes());receipt['caller_source_unchanged']=(CALLER/'pa_core/cli.py').read_bytes()==original;receipt['caller_test_unchanged']=(CALLER/TEST).read_bytes()==caller_test;(output/'controls.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('5 intended assertion RED / exact-restoration GREEN pairs; caller unchanged')

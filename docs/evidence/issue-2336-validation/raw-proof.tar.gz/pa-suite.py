import sys,subprocess,pathlib,json,time,hashlib
p=pathlib.Path(__file__).parent
stage=sys.argv[1]; root='/Users/teacher/.codex/automations/pd-workloop-resume/worktrees/pae-2336-ranked-20261010'
py='/Users/teacher/.codex/automations/imi-merge-verify-closer/work/20261006T2020Z/pae-env/bin/python'
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','pa_core','dashboard','tests','pyproject.toml','.coveragerc'],cwd=root,text=True).splitlines()
(p/f'pa-{stage}-source-inventory.json').write_text(json.dumps({f:hashlib.sha256((pathlib.Path(root)/f).read_bytes()).hexdigest() for f in files},indent=2))
argv=[py,'-m','pytest','--cov=pa_core','--cov=dashboard',f'--cov-report=json:{p}/pa-{stage}-coverage.json','tests/',f'--junitxml={p}/pa-{stage}.xml']
t=time.time()
with (p/f'pa-{stage}.txt').open('w') as o:r=subprocess.run(argv,cwd=root,stdout=o,stderr=subprocess.STDOUT,timeout=900)
receipt={'argv':argv,'cwd':root,'exit':r.returncode,'seconds':time.time()-t,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()}
(p/f'pa-{stage}-process.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))

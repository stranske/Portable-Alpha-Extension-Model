"""Bound and diagnose the unrelated full-suite PNG export stall."""
import json
from pathlib import Path
import subprocess
import sys
import time

out = Path(__file__).parent
argv = [sys.executable, '-m', 'pytest', 'tests/test_cli.py::test_main_with_png',
        '-m', 'not slow and not live_llm', '-q', '-o', 'faulthandler_timeout=30',
        f'--junitxml={out}/png-probe.xml']
started = time.time()
with (out / 'png-probe.log').open('w') as log:
    try:
        p = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, timeout=60)
        result = {'exit': p.returncode, 'timed_out': False}
    except subprocess.TimeoutExpired:
        result = {'exit': None, 'timed_out': True, 'timeout_seconds': 60}
result.update(argv=argv, cwd=str(Path.cwd()), seconds=time.time() - started)
(out / 'png-probe-process.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)

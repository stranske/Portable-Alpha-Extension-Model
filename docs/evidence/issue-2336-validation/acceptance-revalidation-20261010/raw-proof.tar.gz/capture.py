"""Capture scoped validation receipts without changing the working tree's production code."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
import xml.etree.ElementTree as ET

ROOT = Path.cwd()
OUT = Path(__file__).parent
TEST = 'tests/test_cli_validation_boundaries.py'
SOURCE = 'pa_core/cli.py'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def capture(name, args, cwd=ROOT, extra_env=None):
    started = time.time()
    with (OUT / f'{name}.log').open('w') as log:
        process = subprocess.run(args, cwd=cwd, stdout=log, stderr=subprocess.STDOUT,
                                 env=({**os.environ, **extra_env} if extra_env else None),
                                 timeout=900)
    receipt = {'argv': args, 'cwd': str(cwd), 'exit': process.returncode,
               'seconds': time.time() - started}
    (OUT / f'{name}-process.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(name, process.returncode, flush=True)
    return receipt


manifest = json.loads((ROOT / 'docs/evidence/issue-2336-validation/manifest.json').read_text())
archive_path = ROOT / 'docs/evidence/issue-2336-validation/raw-proof.tar.gz'
assert digest(archive_path.read_bytes()) == manifest['archive_sha256']
with tarfile.open(archive_path) as archive:
    members = {member.name: digest(archive.extractfile(member).read())
               for member in archive.getmembers() if member.isfile()}
assert members == manifest['members']
for path, sha in manifest['bindings'].items():
    historic = subprocess.check_output(['git', 'show', f'HEAD:{path}'], cwd=ROOT)
    assert digest(historic) == sha, path
assert digest((ROOT / SOURCE).read_bytes()) == manifest['bindings'][SOURCE]
(OUT / 'historical-integrity.json').write_text(json.dumps({
    'archive_sha256': manifest['archive_sha256'], 'member_count': len(members),
    'all_member_hashes_verified': True, 'historical_head_bindings_verified': True,
    'production_binding_unchanged': True}, indent=2) + '\n')
(OUT / 'environment.json').write_text(json.dumps({
    'python': sys.version, 'executable': sys.executable,
    'versions': {name: importlib.metadata.version(name)
                 for name in ['pytest', 'coverage', 'black', 'ruff', 'numpy', 'pandas']},
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'bindings': {path: digest((ROOT / path).read_bytes())
                 for path in [SOURCE, TEST, 'pyproject.toml']}}, indent=2) + '\n')
selection = ['-m', 'not slow and not live_llm']
focused = capture('focused', [sys.executable, '-m', 'pytest', TEST,
    'tests/test_cli_validate_only.py', '--cov=pa_core.cli', '--cov-report=term-missing',
    f'--cov-report=json:{OUT}/focused-coverage.json', '-q', *selection,
    f'--junitxml={OUT}/focused.xml'])
assert focused['exit'] == 0
for name, args in [('black', ['black', '--check', '--line-length', '100', '--exclude',
                             r'(\.workflows-lib|node_modules)', '.']),
                   ('ruff', ['ruff', 'check', TEST]),
                   ('diff', ['git', 'diff', '--check'])]:
    result = capture(name, args, extra_env={'BLACK_NUM_WORKERS': '1', 'BLACK_CACHE_DIR': '/tmp/pae-validation-black-cache'} if name == 'black' else None)
    assert result['exit'] == 0

guard = 'if any((not r.is_valid) and r.severity == "error" for r in results):'
cases = [('exception-details', 'test_capital_exception_is_a_failed_result_with_original_details',
          'details={"exception": str(exc)},', 'details={"exception": "dropped"},',
          'exception detail lost')]
for severity, exitcode in [('warning', 'None'), ('info', 'None'), ('error', '1')]:
    cases.append((severity, f'test_validation_only_rejects_errors_without_rejecting_advisories[{severity}-{exitcode}]',
                  guard, 'if any(not r.is_valid for r in results):' if severity != 'error' else 'if False:',
                  'validation severity changed exit policy'))
cases.extend([
    ('financing-term', 'test_validation_forwards_effective_financing_and_simulation_settings',
     'term_months=cfg.financing_term_months,', 'term_months=1.0,',
     'effective financing settings were not forwarded'),
    ('effective-config', 'test_validation_forwards_effective_financing_and_simulation_settings',
     'cfg = apply_run_options(cfg, run_options)', 'apply_run_options(cfg, run_options)',
     'effective financing settings were not forwarded'),
    ('logging-restoration', 'test_validation_only_rejects_errors_without_rejecting_advisories[warning-None]',
     'logging.getLogger().removeHandler(self._handler)', 'pass',
     'validation changed caller logging handlers'),
    ('warning-restoration', 'test_validation_only_rejects_errors_without_rejecting_advisories[info-None]',
     '_warnings.showwarning = self._orig_showwarning', 'pass',
     'validation changed caller warning handler'),
])
original = (ROOT / SOURCE).read_bytes()
test_bytes = (ROOT / TEST).read_bytes()
controls = {'source_sha256': digest(original), 'test_sha256': digest(test_bytes), 'cases': []}
with tempfile.TemporaryDirectory(prefix='pae-validation-mutants-') as directory:
    isolated = Path(directory)
    shutil.copytree(ROOT / 'pa_core', isolated / 'pa_core', ignore=shutil.ignore_patterns('__pycache__'))
    (isolated / 'tests').mkdir()
    for path in [TEST, 'tests/conftest.py', 'pyproject.toml']:
        shutil.copy2(ROOT / path, isolated / path)
    source = isolated / SOURCE
    for label, node_name, before, after, marker in cases:
        assert original.decode().count(before) == 1, label
        mutant = original.decode().replace(before, after, 1).encode()
        case = {'name': label, 'node': f'{TEST}::{node_name}', 'before': before,
                'after': after, 'mutant_sha256': digest(mutant), 'phases': []}
        controls['cases'].append(case)
        try:
            for phase, data, expected in [('red', mutant, 1), ('green', original, 0)]:
                source.write_bytes(data)
                for cache in (isolated / 'pa_core/__pycache__').glob('cli.*.pyc'):
                    cache.unlink()
                name = f'{label}-{phase}'
                junit = OUT / f'{name}.xml'
                receipt = capture(name, [sys.executable, '-m', 'pytest', case['node'], '-q',
                                         *selection, f'--junitxml={junit}'], cwd=isolated)
                nodes = ET.parse(junit).getroot().findall('.//testcase')
                assert receipt['exit'] == expected and len(nodes) == 1, name
                node = nodes[0]
                assert node.get('name') == node_name, name
                assert node.find('error') is None and node.find('skipped') is None, name
                failure = node.find('failure')
                if phase == 'red':
                    assert failure is not None, name
                    assert failure.get('message', '').splitlines()[0] == f'AssertionError: {marker}', name
                else:
                    assert failure is None, name
                receipt.update(source_sha256=digest(source.read_bytes()), intended_assertion_verified=True)
                case['phases'].append(receipt)
        finally:
            source.write_bytes(original)
        assert source.read_bytes() == original
    controls['isolated_restored_sha256'] = digest(source.read_bytes())
assert (ROOT / SOURCE).read_bytes() == original
assert (ROOT / TEST).read_bytes() == test_bytes
controls.update(caller_source_unchanged=True, caller_test_unchanged=True)
(OUT / 'mutation-controls.json').write_text(json.dumps(controls, indent=2) + '\n')
print('All historical hashes and eight RED/GREEN mutation pairs verified.', flush=True)

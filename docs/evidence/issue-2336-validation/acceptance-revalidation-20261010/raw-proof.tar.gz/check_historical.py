"""Independently verify the paired historic receipts and reconstruct their comparison."""
from collections import Counter
import json
from pathlib import Path
import tarfile
import xml.etree.ElementTree as ET

out = Path(__file__).parent
root = Path.cwd()
folder = root / 'docs/evidence/issue-2336-validation'
comparison = json.loads((folder / 'comparison.json').read_text())
with tarfile.open(folder / 'raw-proof.tar.gz') as archive:
    covs = [json.loads(archive.extractfile(f'pa-{stage}-coverage.json').read())
            for stage in ('baseline', 'candidate')]
    junit = [ET.fromstring(archive.extractfile(f'pa-{stage}.xml').read())
             for stage in ('baseline', 'candidate')]
    outcomes = []
    for suite in junit:
        cases = suite.findall('.//testcase')
        result = {(n.get('classname'), n.get('name')):
                  ('fail' if n.find('failure') is not None else
                   'error' if n.find('error') is not None else
                   'skip' if n.find('skipped') is not None else 'pass') for n in cases}
        assert len(result) == len(cases)
        outcomes.append(result)
    assert len(outcomes[1]) - len(outcomes[0]) == 5
    assert all(outcomes[1].get(k) == v for k, v in outcomes[0].items())
    for stage, result in zip(('baseline', 'candidate'), outcomes):
        assert dict(Counter(result.values())) == comparison[f'{stage}_outcomes']
    old, new = covs
    assert old['files'].keys() == new['files'].keys()
    deltas = {}
    for filename in old['files']:
        before, after = old['files'][filename], new['files'][filename]
        assert before['excluded_lines'] == after['excluded_lines']
        assert (set(before['executed_lines']) | set(before['missing_lines'])) == (set(after['executed_lines']) | set(after['missing_lines']))
        gains = sorted(set(after['executed_lines']) - set(before['executed_lines']))
        losses = sorted(set(before['executed_lines']) - set(after['executed_lines']))
        assert not losses
        if gains:
            deltas[filename] = {'new': gains, 'lost': losses}
    assert deltas == comparison['line_deltas']
    assert old['totals'] == comparison['baseline']
    assert new['totals'] == comparison['candidate']
    for stage in ('baseline', 'candidate'):
        receipt = json.loads(archive.extractfile(f'pa-{stage}-process.json').read())
        assert receipt['exit'] == 0
    controls = json.loads(archive.extractfile('pa-mutations/controls.json').read())
    assert len(controls['cases']) == 5
    assert all(phase['valid'] for case in controls['cases'] for phase in case['phases'])
    assert controls['caller_source_unchanged'] and controls['caller_test_unchanged']
result = {'historical_comparison_verified': True, 'historical_mutations_verified': 5,
          'new_testcases': 5, 'pre_existing_outcome_changes': {},
          'baseline_outcomes': comparison['baseline_outcomes'],
          'candidate_outcomes': comparison['candidate_outcomes'],
          'covered_lines': [old['totals']['covered_lines'], new['totals']['covered_lines']],
          'statements': new['totals']['num_statements'], 'files': len(new['files']),
          'exclusions': new['totals']['excluded_lines'], 'line_deltas': deltas}
(out / 'historical-comparison-verified.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))

"""Compare the pre-existing suite with the same suite plus five boundary cases."""
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path.cwd()
out = Path(__file__).parent
for stage in ['baseline', 'candidate']:
    argv = [sys.executable, '-m', 'pytest', 'tests/', '-m', 'not slow and not live_llm',
            '--cov=pa_core', '--cov=dashboard', f'--cov-report=json:{out}/{stage}-coverage.json',
            f'--junitxml={out}/{stage}.xml']
    if stage == 'baseline':
        argv.append('--ignore=tests/test_cli_validation_boundaries.py')
    started = time.time()
    with (out / f'{stage}.log').open('w') as log:
        result = subprocess.run(argv, cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=900)
    receipt = {'argv': argv, 'cwd': str(root), 'exit': result.returncode,
               'seconds': time.time() - started}
    (out / f'{stage}-process.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(stage, result.returncode, flush=True)

"""Run Black's unchanged single-file formatter without worker scheduling."""
import black
import black.concurrency


def reformat_many(sources, fast, write_back, mode, report, workers, no_cache=False):
    for source in sorted(sources):
        black.reformat_one(source, fast, write_back, mode, report, no_cache=no_cache)


black.concurrency.reformat_many = reformat_many

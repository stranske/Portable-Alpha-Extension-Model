Related to #2336. Add six bounded CLI sweep packet export failure cases for RuntimeError, ImportError, ModuleNotFoundError, ValueError, TypeError and KeyError. Each checks truthful diagnostics/remediation, one export attempt, no false success announcement, and preservation of the sweep workbook and manifest. Production is unchanged; export/rendering is stubbed.

## Tasks and acceptance

- [x] Six named cases pass; six real production mutant executions fail their exact nodes, followed by byte-identical restored GREEN. Three distinct handler mutant shapes; caller source/tests preserved and existing output refused before mutation.
- [x] Full matched suite:1643→1649PASS, unchanged1SKIP/2default-deselected, exactly six new nodes/zero changed old outcomes, both commands exit0.
- [x] Coverage12149→12159/14554 statements (83.4753→83.5440%); CLI810→820/1107. Identical186source files/181excluded lines and no covered-line regression. No floor, selection, exclusion or production change.
- [x] Fresh last500 source-touching commits rank CLI first:21 repair-subject proxy matches/133touches/297uncovered lines. Proxy is not verified escaped-defect history.
- [x] Full Black482files, focused Ruff, diff and all56raw archive/member/input SHA256 bindings pass.

## Reproduce

```sh
python3 -m pytest tests/test_cli_sweep_export_failures.py -q -o addopts=
python3 docs/evidence/issue-2336-sweep-export-failures/replay_sweep_export_failures.py --output /tmp/new-sweep-export-proof
python3 -m pytest --cov=pa_core --cov=dashboard --cov-report=json:coverage.json tests/
```

Complete logs/JUnit/coverage/argv/cwd/process exits/source/test/replay snapshots, ranking, mutations and reuse proof are retained in `docs/evidence/issue-2336-sweep-export-failures/validation.tar.gz`, bound by `manifest.json`; `comparison.json` names every new node and unchanged outcome. Local isolated Python3.12.2 uses the prior NumPy/pandas/xarray overlay; raw warnings retained, no hosted parity claim.

Broader #2336 remains OPEN below90%; no providerPASS or merge authorization. Matching Codex keepalive owns hosted checks/reviews; closer requires complete exact-head topology, zero active threads, seven-minute review floor, guarded merge and actualcompare/bounded disposition. This independent test-only chunk does not clear Workflows key3820.


<!-- This is an auto-generated comment: release notes by coderabbit.ai -->
## Summary by CodeRabbit

- [x] **Tests**
  - [x] Added regression coverage for sweep-export failures, verifying error-specific diagnostics and guidance, preventing false success messages, and confirming workbook and manifest contents are preserved.
  - [x] Added mutation-based checks to validate that the regression tests detect changes to failure handling.
- [x] **Documentation**
  - [x] Added baseline and candidate test and coverage comparisons, reproduction instructions, and archived validation evidence with integrity checks.
  - [x] Recorded that broader source coverage remains below 90% and that the evidence does not establish hosted-environment parity or authorize a merge.
<!-- end of auto-generated comment: release notes by coderabbit.ai -->

Reconciled after reviewing commits 943d00cc through 29ab2016: all five archived validation bundles pass their SHA256 member checks; the current six failure cases and nine existing sweep-export cases pass. Later focused receipts strengthen the tests; the matched full-suite counts above remain historical measurements. Production remains unchanged. See docs/evidence/issue-2336-sweep-export-failures/README.md for snapshot-specific evidence and limitations.

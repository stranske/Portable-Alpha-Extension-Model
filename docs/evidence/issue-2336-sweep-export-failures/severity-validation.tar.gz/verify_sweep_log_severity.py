"""Prove dependency/data failure diagnostics retain ERROR severity."""

import argparse
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

SOURCE = "pa_core/cli.py"
TEST = "tests/test_cli_sweep_export_failures.py"
PARENT = "e34d990a8b274cd1043e59e5fd7afe624fc74d6d"
CASES = {"runtime", "import", "module", "value", "type", "key"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    root = Path.cwd()
    caller = {name: (root / name).read_bytes() for name in (SOURCE, TEST)}
    parent = subprocess.check_output(["git", "show", f"{PARENT}:{TEST}"], cwd=root)
    archive = subprocess.check_output(["git", "archive", PARENT], cwd=root)
    controls = {"parent_commit": PARENT, "phases": []}
    with tempfile.TemporaryDirectory(prefix="pa-sweep-logs-") as tmp:
        tree = Path(tmp)
        with tarfile.open(fileobj=io.BytesIO(archive)) as bundle:
            bundle.extractall(tree, filter="data")
        source = tree / SOURCE
        original = source.read_bytes()
        assert original == caller[SOURCE]
        text = original.decode()
        start = text.index("        # Handle packet export for parameter sweep mode")
        end = text.index("        # Sensitivity analysis can also", start)
        section = text[start:end]
        handlers = (
            "except RuntimeError as e:",
            "except (ImportError, ModuleNotFoundError) as e:",
            "except (ValueError, TypeError, KeyError) as e:",
        )
        for kind in ("severity",):
            assertion = "export_logs"
            assert section.count("logger.error(") == 2
            changed = section.replace("logger.error(", "logger.info(")
            mutant = (text[:start] + changed + text[end:]).encode()
            affected = CASES - {"runtime"}
            for phase, test_bytes, production, failures in (
                ("parent-mutant", parent, mutant, set()),
                ("candidate-mutant", caller[TEST], mutant, affected),
                ("candidate-restored", caller[TEST], original, set()),
            ):
                name = f"{kind}-{phase}"
                source.write_bytes(production)
                (tree / TEST).write_bytes(test_bytes)
                for cached in (tree / "pa_core/__pycache__").glob("cli.*.pyc"):
                    cached.unlink()
                report = output / f"{name}.xml"
                argv = [
                    sys.executable,
                    "-m",
                    "pytest",
                    TEST,
                    "-q",
                    "-o",
                    "addopts=",
                    "-m",
                    "not slow",
                    f"--junitxml={report}",
                ]
                env = dict(os.environ)
                env.pop("PYTEST_ADDOPTS", None)
                proc = subprocess.run(
                    argv, cwd=tree, env=env, capture_output=True, text=True, timeout=120
                )
                (output / f"{name}.txt").write_text(proc.stdout + proc.stderr)
                nodes = list(ET.parse(report).getroot().iter("testcase"))
                assert proc.returncode == (1 if failures else 0), name
                assert len(nodes) == 6
                assert not any(
                    n.find("error") is not None or n.find("skipped") is not None for n in nodes
                )
                assert {n.get("name") for n in nodes} == {
                    f"test_sweep_packet_export_failure_is_truthful[{case}]" for case in CASES
                }
                actual = set()
                for node in nodes:
                    assert node.get("classname") == "tests.test_cli_sweep_export_failures"
                    failure = node.find("failure")
                    if failure is not None:
                        actual.add(node.get("name").rsplit("[", 1)[1].removesuffix("]"))
                        assert assertion in failure.text
                assert actual == failures, name
                controls["phases"].append(
                    {
                        "name": name,
                        "argv": argv,
                        "cwd": str(tree),
                        "exit": proc.returncode,
                        "source_sha256": digest(source.read_bytes()),
                        "test_sha256": digest(test_bytes),
                        "failed_cases": sorted(actual),
                    }
                )
            assert source.read_bytes() == original
    assert not tree.exists()
    assert all((root / name).read_bytes() == content for name, content in caller.items())
    controls.update(
        caller_preserved=True,
        private_tree_removed=True,
        caller_sha256={name: digest(content) for name, content in caller.items()},
    )
    (output / "controls.json").write_text(json.dumps(controls, indent=2) + "\n")
    print("INFO downgrade passes six parent cases, fails five candidate cases, restores six GREEN.")


if __name__ == "__main__":
    main()

"""Validate the parent-package patch in a private committed source tree."""

import argparse
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    root = Path.cwd()
    test_name = "tests/test_cli_sweep_export_failures.py"
    caller = {name: digest((root / name).read_bytes()) for name in (test_name, "pa_core/cli.py")}
    current = (root / test_name).read_bytes()
    patch = '    monkeypatch.setattr(pa_core, "viz", viz)\n'
    assert current.decode().count(patch) == 1
    guard = """    def reject_real_renderer(*_args, **_kwargs):
        raise AssertionError("Real renderer reached instead of stub")

    monkeypatch.setattr(pa_core.viz.risk_return, "make", reject_real_renderer)
    monkeypatch.setattr(pa_core.viz.sharpe_ladder, "make", reject_real_renderer)
"""
    candidate = current.decode().replace(
        "    figure = object()\n", guard + "    figure = object()\n"
    )
    mutant = candidate.replace(patch, "")
    revision = "81a9c7141839704ae004385e64453198383f1e53"
    previous = subprocess.check_output(
        ["git", "show", f"{revision}:{test_name}"], cwd=root, text=True
    )
    previous = previous.replace(
        '    viz = types.ModuleType("pa_core.viz")\n',
        guard + '    viz = types.ModuleType("pa_core.viz")\n',
    )
    previous = previous.replace(
        "from pa_core.cli import main", "import pa_core\nfrom pa_core.cli import main"
    )
    archive = subprocess.check_output(["git", "archive", revision], cwd=root)
    receipts = []
    with tempfile.TemporaryDirectory(prefix="pa-viz-isolation-") as tmp:
        tree = Path(tmp)
        with tarfile.open(fileobj=io.BytesIO(archive)) as bundle:
            bundle.extractall(tree, filter="data")
        source_hash = digest((tree / "pa_core/cli.py").read_bytes())
        assert source_hash == caller["pa_core/cli.py"]
        for phase, test, expected in (
            ("parent", previous, 1),
            ("missing-parent-patch", mutant, 1),
            ("guarded-candidate", candidate, 0),
            ("restored-candidate", current.decode(), 0),
        ):
            (tree / test_name).write_text(test)
            report = output / f"{phase}.xml"
            command = [
                sys.executable,
                "-m",
                "pytest",
                test_name,
                "-q",
                "-o",
                "addopts=",
                "-m",
                "not slow",
                f"--junitxml={report}",
            ]
            result = subprocess.run(
                command, cwd=tree, capture_output=True, text=True, timeout=120, check=False
            )
            (output / f"{phase}.txt").write_text(result.stdout + result.stderr)
            nodes = list(ET.parse(report).getroot().iter("testcase"))
            assert result.returncode == expected
            assert {node.get("name") for node in nodes} == {
                f"test_sweep_packet_export_failure_is_truthful[{case}]"
                for case in ("runtime", "import", "module", "value", "type", "key")
            }
            assert all(
                node.find("error") is None and node.find("skipped") is None for node in nodes
            )
            assert all((node.find("failure") is not None) == (expected == 1) for node in nodes)
            if expected:
                assert all(
                    "Real renderer reached instead of stub" in node.find("failure").text
                    for node in nodes
                )
            assert digest((tree / "pa_core/cli.py").read_bytes()) == source_hash
            receipts.append(
                {
                    "phase": phase,
                    "argv": command,
                    "cwd": str(tree),
                    "exit": result.returncode,
                    "test_sha256": digest((tree / test_name).read_bytes()),
                    "production_sha256": source_hash,
                }
            )
        assert (tree / test_name).read_bytes() == current
    assert caller == {name: digest((root / name).read_bytes()) for name in caller}
    (output / "controls.json").write_text(
        json.dumps(
            {"snapshot_commit": revision, "caller_unchanged": caller, "receipts": receipts},
            indent=2,
        )
        + "\n"
    )
    print(
        "Six parent failures; six missing-patch failures; six guarded passes; six exact restored passes."
    )


if __name__ == "__main__":
    main()

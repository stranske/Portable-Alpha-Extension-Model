"""Verify that the snapshot assertions reject lost manifest provenance."""
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path
from defusedxml import ElementTree as ET

root = Path.cwd()
output = Path('/tmp/sweep-snapshot-proof')
source_name = 'pa_core/cli.py'
test_name = 'tests/test_cli_sweep_export_failures.py'
before = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in (source_name, test_name)}
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
archive = subprocess.check_output(['git', 'archive', revision])
with tempfile.TemporaryDirectory(prefix='pa-manifest-preservation-') as tmp:
    tree = Path(tmp)
    with tarfile.open(fileobj=io.BytesIO(archive)) as bundle:
        bundle.extractall(tree, filter='data')
    source = tree / source_name
    original = source.read_bytes()
    anchor = '        data["run_timing"] = timing\n'
    assert original.decode().count(anchor) == 1
    mutant = original.decode().replace(anchor, anchor + '        data.pop("backend", None)\n').encode()
    source.write_bytes(mutant)
    for phase, expected_exit, expected_failures in [('parent-mutant', 0, 0), ('snapshot-mutant', 1, 6), ('snapshot-restored', 0, 0)]:
        if phase != 'parent-mutant':
            (tree / test_name).write_bytes((root / test_name).read_bytes())
        if phase == 'snapshot-restored':
            source.write_bytes(original)
        report = output / (phase + '.xml')
        command = [sys.executable, '-m', 'pytest', test_name, '-q', '-o', 'addopts=', '-m', 'not slow', '--junitxml=' + str(report)]
        result = subprocess.run(command, cwd=tree, capture_output=True, text=True, timeout=120)
        (output / (phase + '.txt')).write_text(result.stdout + result.stderr)
        (output / (phase + '-command.json')).write_text(json.dumps({'argv': command, 'cwd': str(tree), 'exit': result.returncode, 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'test_sha256': hashlib.sha256((tree / test_name).read_bytes()).hexdigest()}, indent=2) + '\n')
        cases = list(ET.parse(report).getroot().iter('testcase'))
        assert result.returncode == expected_exit, phase
        assert len(cases) == 6
        assert sum(c.find('failure') is not None for c in cases) == expected_failures
        assert all(c.find('error') is None and c.find('skipped') is None for c in cases)
        assert {c.get('name') for c in cases} == {'test_sweep_packet_export_failure_is_truthful[' + name + ']' for name in ('runtime', 'import', 'module', 'value', 'type', 'key')}
        if expected_failures:
            assert all("'backend': 'numpy'" in c.find('failure').text for c in cases)
        print(phase, ':', len(cases), 'cases;', expected_failures, 'failures; exit', result.returncode)
    assert source.read_bytes() == original
current = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in before}
assert current == before
(output / 'manifest-mutation-controls.json').write_text(json.dumps({'snapshot_commit': revision, 'mutation': 'remove backend during manifest finalization', 'caller_before': before, 'caller_after': current, 'production_unchanged': True, 'parent_mutant_passes': 6, 'snapshot_mutant_failures': 6, 'snapshot_restored_passes': 6}, indent=2) + '\n')

import hashlib
import json
import subprocess
import sys
import tarfile
from pathlib import Path
from defusedxml import ElementTree as ET

root=Path.cwd()
output=Path('/tmp/sweep-snapshot-proof')
evidence=root/'docs/evidence/issue-2336-sweep-export-failures'
def digest(data):
    return hashlib.sha256(data).hexdigest()
def hashes(directory):
    return {str(p.relative_to(directory)):digest(p.read_bytes()) for p in directory.rglob('*') if p.is_file()}
mutation_before=hashes(output/'mutations')
caller_before={name:digest((root/name).read_bytes()) for name in ('pa_core/cli.py','tests/test_cli_sweep_export_failures.py')}
command=[sys.executable,str(evidence/'replay_sweep_export_failures.py'),'--output',str(output/'mutations')]
result=subprocess.run(command,capture_output=True,text=True,timeout=120)
(output/'reuse.txt').write_text(result.stdout+result.stderr)
assert result.returncode==1
assert 'FileExistsError' in result.stderr
assert hashes(output/'mutations')==mutation_before
assert {name:digest((root/name).read_bytes()) for name in caller_before}==caller_before
(output/'reuse-command.json').write_text(json.dumps({'argv':command,'cwd':str(root),'exit':result.returncode,'receipts_preserved':True,'caller_preserved':True},indent=2)+'\n')
for name,command in [('ruff',['ruff','check','tests/test_cli_sweep_export_failures.py']),('diff',['git','diff','--check'])]:
    result=subprocess.run(command,capture_output=True,text=True,check=False)
    (output/(name+'.txt')).write_text(result.stdout+result.stderr)
    (output/(name+'-command.json')).write_text(json.dumps({'argv':command,'cwd':str(root),'exit':result.returncode},indent=2)+'\n')
    assert result.returncode==0
focused_cases=list(ET.parse(output/'focused.xml').getroot().iter('testcase'))
assert len(focused_cases)==15
assert all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in focused_cases)
controls=json.loads((output/'mutations/controls.json').read_text())
assert len(controls['cases'])==6
assert controls['caller_before']==controls['caller_after']==caller_before
assert len({c['mutant_sha256'] for c in controls['cases']})==3
for case in controls['cases']:
    assert case['red_exit']==1 and case['green_exit']==0
    assert case['restored_sha256']==caller_before['pa_core/cli.py']
coverage=json.loads((output/'coverage.json').read_text())['files']['pa_core/cli.py']
assert set(range(1487,1497))<=set(coverage['executed_lines'])
assert '493 files would be left unchanged.' in (output/'black.txt').read_text()
verification={'focused_passes':15,'handler_mutation_failures':6,'handler_restored_passes':6,'lost_backend_parent_passes':6,'lost_backend_snapshot_failures':6,'lost_backend_restored_passes':6,'reuse_refused_and_preserved':True,'black_files':493,'targeted_cli_coverage':coverage['summary'],'targeted_handler_lines':list(range(1487,1497)),'production_unchanged':True,'hosted_parity_established':False,'merge_authorized':False,'pr_body_updated':False}
(output/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
(output/'focused-command.json').write_text(json.dumps({'argv':['black','--line-length','100','tests/test_cli_sweep_export_failures.py'],'next_argv':['python3','-m','pytest','tests/test_cli_sweep_export_failures.py','tests/test_cli_sweep_png_export.py','-q','-o','addopts=','-m','not slow','--junitxml='+str(output/'focused.xml')],'cwd':str(root),'exit':0},indent=2)+'\n')
(output/'black-command.json').write_text(json.dumps({'argv':['black','--check','--line-length','100','--exclude',r'(\.workflows-lib|node_modules)', '.'],'cwd':str(root),'PYTHONPATH':str(output/'black-runtime'),'exit':0},indent=2)+'\n')
(output/'coverage-command.json').write_text(json.dumps({'argv':['python3','-m','pytest','tests/test_cli_sweep_export_failures.py','--cov=pa_core.cli','--cov-report=term-missing','--cov-report=json:'+str(output/'coverage.json'),'-q','-o','addopts=','-m','not slow'],'cwd':str(root),'exit':0},indent=2)+'\n')
inputs={name:digest((root/name).read_bytes()) for name in (*caller_before,'docs/evidence/issue-2336-sweep-export-failures/replay_sweep_export_failures.py')}
for filename,repo_name in [('snapshot-test.py','tests/test_cli_sweep_export_failures.py'),('snapshot-production.py','pa_core/cli.py'),('snapshot-replay.py','docs/evidence/issue-2336-sweep-export-failures/replay_sweep_export_failures.py')]:
    (output/filename).write_bytes((root/repo_name).read_bytes())
files=[p for p in output.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='pr-body.md']
archive=evidence/'snapshot-validation.tar.gz'
with tarfile.open(archive,'w:gz') as bundle:
    for p in sorted(files):
        bundle.add(p,arcname=str(p.relative_to(output)))
manifest={'archive_sha256':digest(archive.read_bytes()),'members_sha256':{str(p.relative_to(output)):digest(p.read_bytes()) for p in sorted(files)},'inputs_sha256':inputs,'prior_manifests_sha256':{name:digest((evidence/name).read_bytes()) for name in ('manifest.json','acceptance-manifest.json')},'verification':verification}
(evidence/'snapshot-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as bundle:
    assert {m.name:digest(bundle.extractfile(m).read()) for m in bundle.getmembers() if m.isfile()}==manifest['members_sha256']
print('Verified',len(files),'snapshot receipt members; preservation and formatting checks pass.')

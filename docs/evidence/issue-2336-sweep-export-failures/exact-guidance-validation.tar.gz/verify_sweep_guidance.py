"""Prove the six sweep cases detect an incorrect dependency remediation command."""

import argparse
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

SOURCE = "pa_core/cli.py"
TEST = "tests/test_cli_sweep_export_failures.py"
PARENT = "088f2bbd1c3f9d0fbe9ae7434df734e95ef26b3b"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    output = parser.parse_args().output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    root = Path.cwd()
    source_bytes = (root / SOURCE).read_bytes()
    candidate = (root / TEST).read_bytes()
    parent = subprocess.check_output(["git", "show", f"{PARENT}:{TEST}"], cwd=root)
    archive = subprocess.check_output(["git", "archive", PARENT], cwd=root)
    controls = {"parent_commit": PARENT, "phases": []}
    with tempfile.TemporaryDirectory(prefix="pa-sweep-guidance-") as tmp:
        tree = Path(tmp)
        with tarfile.open(fileobj=io.BytesIO(archive)) as bundle:
            bundle.extractall(tree, filter="data")
        source = tree / SOURCE
        original = source.read_bytes()
        assert original == source_bytes
        text = original.decode()
        start = text.index("        # Handle packet export for parameter sweep mode")
        end = text.index("        # Sensitivity analysis can also", start)
        section = text[start:end]
        before = "Install required packages: pip install plotly kaleido openpyxl"
        after = "Install required packages: pip install plotly"
        assert section.count(before) == 1
        mutant = (text[:start] + section.replace(before, after) + text[end:]).encode()
        for name, test_bytes, production, failures in (
            ("parent-mutant", parent, mutant, set()),
            ("candidate-mutant", candidate, mutant, {"import", "module"}),
            ("candidate-restored", candidate, original, set()),
        ):
            source.write_bytes(production)
            (tree / TEST).write_bytes(test_bytes)
            report = output / f"{name}.xml"
            argv = [
                sys.executable,
                "-m",
                "pytest",
                TEST,
                "-q",
                "-o",
                "addopts=",
                "-m",
                "not slow",
                f"--junitxml={report}",
            ]
            env = dict(os.environ)
            env.pop("PYTEST_ADDOPTS", None)
            proc = subprocess.run(
                argv, cwd=tree, env=env, capture_output=True, text=True, timeout=120
            )
            (output / f"{name}.txt").write_text(proc.stdout + proc.stderr)
            nodes = list(ET.parse(report).getroot().iter("testcase"))
            assert proc.returncode == (1 if failures else 0)
            assert len(nodes) == 6
            assert not any(
                n.find("error") is not None or n.find("skipped") is not None for n in nodes
            )
            actual = {
                n.get("name").rsplit("[", 1)[1].removesuffix("]")
                for n in nodes
                if n.find("failure") is not None
            }
            assert actual == failures
            for node in nodes:
                failure = node.find("failure")
                if failure is not None:
                    assert "guidance_lines" in failure.text
            controls["phases"].append(
                {
                    "name": name,
                    "argv": argv,
                    "cwd": str(tree),
                    "exit": proc.returncode,
                    "source_sha256": digest(production),
                    "test_sha256": digest(test_bytes),
                    "failed_cases": sorted(actual),
                }
            )
        assert source.read_bytes() == original
    assert (root / SOURCE).read_bytes() == source_bytes
    assert (root / TEST).read_bytes() == candidate
    assert not tree.exists()
    controls.update(caller_preserved=True, private_tree_removed=True)
    (output / "controls.json").write_text(json.dumps(controls, indent=2) + "\n")
    print(
        "Parent accepts incorrect remediation; candidate rejects import/module; restoration passes."
    )


if __name__ == "__main__":
    main()

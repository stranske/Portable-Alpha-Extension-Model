"""Prove both warning nodes reject copying only the context dictionary."""

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


root = Path.cwd()
output = Path(sys.argv[1]).resolve()
output.mkdir(parents=True, exist_ok=False)
source = Path("pa_core/cli.py")
test = Path("tests/test_cli_observability_boundaries.py")
original = (root / source).read_bytes()
before = "return deepcopy(self.records)"
after = 'return [{**rec, "context": dict(rec["context"])} for rec in self.records]'
assert original.decode().count(before) == 1
mutant = original.decode().replace(before, after, 1).encode()
controls = {
    "source_sha256": digest(original),
    "test_sha256": digest((root / test).read_bytes()),
    "before": before,
    "after": after,
    "mutant_sha256": digest(mutant),
    "cases": [],
}
with tempfile.TemporaryDirectory(prefix="cli-context-only-replay-") as temporary:
    isolated = Path(temporary)
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=root).split(b"\0")
    for raw in filter(None, tracked):
        relative = Path(raw.decode())
        target = isolated / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / relative, target)
    try:
        for index, kind in enumerate(["logging", "warnings"]):
            name = f"test_warning_snapshot_context_is_detached_from_collector[{kind}]"
            case = {"node": str(test) + "::" + name, "phases": []}
            controls["cases"].append(case)
            for phase, content, expected in [("red", mutant, 1), ("green", original, 0)]:
                (isolated / source).write_bytes(content)
                for cache in (isolated / "pa_core/__pycache__").glob("cli.*.pyc"):
                    cache.unlink()
                stem = f"{index:02d}-{phase}"
                junit = output / (stem + ".xml")
                argv = [
                    sys.executable,
                    "-m",
                    "pytest",
                    case["node"],
                    "-m",
                    "not slow",
                    "-q",
                    "--junitxml=" + str(junit),
                ]
                with (output / (stem + ".txt")).open("w") as stream:
                    proc = subprocess.run(
                        argv,
                        cwd=isolated,
                        stdout=stream,
                        stderr=subprocess.STDOUT,
                        timeout=90,
                        check=False,
                    )
                nodes = ET.parse(junit).getroot().findall(".//testcase")
                assert len(nodes) == 1 and nodes[0].get("name") == name
                assert nodes[0].find("error") is None and nodes[0].find("skipped") is None
                assert (nodes[0].find("failure") is not None) == (phase == "red")
                assert proc.returncode == expected
                case["phases"].append(
                    {
                        "phase": phase,
                        "exit": proc.returncode,
                        "argv": argv,
                        "cwd": str(isolated),
                        "source_sha256": digest((isolated / source).read_bytes()),
                        "console": stem + ".txt",
                        "junit": stem + ".xml",
                    }
                )
    finally:
        (isolated / source).write_bytes(original)
        controls["restored_sha256"] = digest((isolated / source).read_bytes())
        assert controls["restored_sha256"] == controls["source_sha256"]
        (output / "controls.json").write_text(json.dumps(controls, indent=2) + "\n")
assert (root / source).read_bytes() == original
assert digest((root / test).read_bytes()) == controls["test_sha256"]
print("2 warning nodes: context-only shallow copy RED, byte-identical deepcopy GREEN")

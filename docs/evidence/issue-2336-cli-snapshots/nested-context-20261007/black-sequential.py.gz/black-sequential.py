import hashlib
import json
import sys
import tomllib
from pathlib import Path

import black

root = Path.cwd()
config = tomllib.loads((root / "pyproject.toml").read_text())["tool"]["black"]
report = black.Report(check=True)
sources = black.get_sources(
    root=root,
    src=(".",),
    quiet=False,
    verbose=False,
    include=black.re_compile_maybe_verbose(config["include"]),
    exclude=black.re_compile_maybe_verbose(r"(\.workflows-lib|node_modules)"),
    extend_exclude=black.re_compile_maybe_verbose(config["extend-exclude"]),
    force_exclude=None,
    report=report,
    stdin_filename=None,
)
mode = black.Mode(line_length=100, target_versions={black.TargetVersion[version.upper()] for version in config["target-version"]})
hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
for path in sorted(sources):
    # Use Black's normal single-file check and cache-writing implementation.
    black.reformat_one(path, fast=False, write_back=black.WriteBack.CHECK, mode=mode, report=report)
assert hashes == {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
receipt = {"black_version": black.__version__, "scope": "Black get_sources with the exact required command's include/exclude and repository configuration", "files": len(sources), "unchanged": report.same_count, "would_reformat": report.change_count, "errors": report.failure_count, "exit": report.return_code, "source_hashes_unchanged": hashes}
Path("/tmp/cli-deep-context-black-sequential-results.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(str(report))
sys.exit(report.return_code)

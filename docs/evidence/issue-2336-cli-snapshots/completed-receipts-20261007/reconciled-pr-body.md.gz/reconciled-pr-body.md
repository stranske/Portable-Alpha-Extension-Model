Related to #2336; one bounded coverage/bugfix chunk after merged #2341. The broader 90% initiative stays open.

Warning snapshots copied only the outer record, so callers could change stored diagnostic context through a snapshot. Deep-copy the snapshot and add six regression cases for both warning sources, monthly-return/benchmark summaries, original configuration bytes and monotonic UTC timing.

## Scoped tasks and acceptance
- [x] Reproduce nested context aliasing for logging and Python warnings; fix only the snapshot copy boundary.
- [x] Add six named cases; every new case fails under an actual production mutation and passes after byte-identical restoration.
- [x] Preserve existing scope and test outcomes: full baseline1606PASS → candidate1612PASS; both1skip/2default-deselected, exit0. Exactly six new nodes, zero old-outcome changes or covered-line regressions.
- [x] Measure coverage12140/14553 →12143/14554 (83.419226%→83.434107%); broader90% remains unfulfilled.
- [x] Focused diagnostic/replay-isolation18PASS; standard Orchestrator base-overlay RED1/GREEN0; all14 current boundary nodes have explicit production RED/restoredGREEN proof.
- [x] Full-repository Black477files and focusedRuff pass; optional notebook formatting unavailable, disclosed.

Evidence: docs/evidence/issue-2336-cli-snapshots/README.md, full lossless coverage/JUnit/console, current history ranking, process receipts, per-node mutation controls and stored/decoded hash manifest. The same isolated Python3.12+xarray2026.9 overlay ran both full suites; shared-native-extension diagnostics remain retained and hosted parity is unclaimed.

The prior replay anchor is updated for deepcopy; current replay/source/test file entries are refreshed, with the original manifest and historical proof preserved. No workflow, dependency policy, floor, exclusion, skipped-test policy or unrelated product change.

Keepalive owns fresh hosted checks/review recovery. Reviewed Repo Merge Verify Closer owns complete expected topology, unchanged head, full review threads and seven-minute activity floor, guarded merge, actual verify:compare and bounded acceptance. Source2336 remains open for the next ranked chunk. No provider PASS or full90% completion is claimed.

## Acceptance Criteria

- [x] **Bug Fixes**
  - [x] Warning snapshots now preserve nested context independently, so later changes to captured data do not affect existing snapshots.
- [x] **Tests**
  - [x] Expanded checks for CLI reporting, configuration snapshots, timer behavior, and replay-driver recovery when interrupted.
- [x] **Documentation**
  - [x] Added evidence and replay records for the regression fix, test results, and interruption handling.

Reconciled after reviewing commits 4766bb39 through 58e79783 and rerunning the focused suite: 20 passed, including both warning sources and timeout/KeyboardInterrupt restoration. Regression and replay evidence: `docs/evidence/issue-2336-cli-snapshots/nested-context-20261007/README.md`. Full-suite and coverage comparisons above are historical; the broader 90% initiative remains open.


<!-- This is an auto-generated comment: release notes by coderabbit.ai -->
## Summary by CodeRabbit

- **Bug Fixes**
  - Warning snapshots now preserve nested context independently, so later changes to captured data do not affect existing snapshots.
- **Tests**
  - Expanded checks for CLI reporting, configuration snapshots, timer behavior, and replay-driver recovery when interrupted.
- **Documentation**
  - Added evidence and replay records for the regression fix, test results, and interruption handling.
<!-- end of auto-generated comment: release notes by coderabbit.ai -->

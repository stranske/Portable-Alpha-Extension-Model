"""Prove interruption receipts reject dropped phases using a private driver mutation."""

import hashlib
import json
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path.cwd()
proof = Path(sys.argv[1]).resolve()
proof.mkdir(parents=True, exist_ok=False)
private = proof / "checkout"
paths = [
    "pa_core/cli.py",
    "tests/test_cli_mutation_replay_isolation.py",
    "tests/test_cli_observability_boundaries.py",
    "docs/evidence/issue-2336-next-boundaries/replay.py",
    "docs/evidence/issue-2336-cli-snapshots/replay.py",
]
for relative in paths:
    target = private / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / relative, target)
driver = private / paths[-1]
original = driver.read_bytes()
before = b'case["phases"].append(record)'
after = b"pass  # mutation: discard completed phase receipts"
assert original.count(before) == 1
mutant = original.replace(before, after, 1)
argv = [
    sys.executable,
    "-m",
    "pytest",
    "tests/test_cli_mutation_replay_isolation.py::test_snapshot_replay_restores_source_after_phase_failure",
    "-m",
    "not slow",
    "-q",
]
controls = {
    "mutation": "Discard completed phase receipts in actual snapshot replay driver",
    "driver_sha256": hashlib.sha256(original).hexdigest(),
    "mutant_sha256": hashlib.sha256(mutant).hexdigest(),
    "phases": [],
}
try:
    for phase, content, expected in [("red", mutant, 1), ("green", original, 0)]:
        driver.write_bytes(content)
        for cache in driver.parent.glob("__pycache__/replay.*.pyc"):
            cache.unlink()
        junit = proof / f"{phase}.xml"
        command = argv + [f"--junitxml={junit}"]
        with (proof / f"{phase}.log").open("w") as stream:
            process = subprocess.run(
                command,
                cwd=private,
                stdout=stream,
                stderr=subprocess.STDOUT,
                timeout=60,
                check=False,
            )
        nodes = ET.parse(junit).getroot().findall(".//testcase")
        assert len(nodes) == 2
        assert {node.get("name") for node in nodes} == {
            f"test_snapshot_replay_restores_source_after_phase_failure[{interruption}]"
            for interruption in ("timeout", "keyboard")
        }
        assert all(node.find("error") is None and node.find("skipped") is None for node in nodes)
        failures = sum(node.find("failure") is not None for node in nodes)
        assert failures == (2 if phase == "red" else 0)
        controls["phases"].append(
            {
                "phase": phase,
                "argv": command,
                "cwd": str(private),
                "exit": process.returncode,
                "named_failures": failures,
            }
        )
        assert process.returncode == expected
finally:
    driver.write_bytes(original)
    controls["restored_sha256"] = hashlib.sha256(driver.read_bytes()).hexdigest()
    (proof / "controls.json").write_text(json.dumps(controls, indent=2) + "\n")
assert driver.read_bytes() == original
print("Completed-receipt mutation: 2 named failures RED, byte-identical restored 2 passes GREEN")

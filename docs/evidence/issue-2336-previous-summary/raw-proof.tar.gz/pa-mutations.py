import subprocess,json,hashlib,time
from pathlib import Path
E=Path(__file__).parent;W=Path('/Users/teacher/.codex/automations/pd-workloop-resume/worktrees/pa2336-summary-candidate-20261010T1800Z');PY='/Users/teacher/.codex/automations/imi-merge-verify-closer/work/20261006T2020Z/pae-env/bin/python';P=W/'pa_core/cli.py';T=W/'tests/test_cli_packet_diff.py';original=P.read_bytes();caller=T.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest()
old=b'                    except (ImportError, OSError, PermissionError, ValueError):\n                        prev_summary_df = pd.DataFrame()';new=b'                    except RuntimeError:\n                        prev_summary_df = pd.DataFrame()';assert original.count(old)==1
rows=[]
try:
 for case in ['missing-engine','io-error','permission-error','invalid-workbook']:
  node=f'tests/test_cli_packet_diff.py::test_sweep_packet_passes_prev_diff[{case}]';row={'node':node,'production_mutation':'Replace only the previous-summary read fallback exception tuple with RuntimeError','original_sha256':sha(original),'test_sha256':sha(caller),'phases':[]}
  for phase in ['red','green']:
   P.write_bytes(original.replace(old,new) if phase=='red' else original)
   argv=[PY,'-m','pytest',node,'-q',f'--junitxml={E}/mutation-{case}-{phase}.xml'];start=time.time()
   with (E/f'mutation-{case}-{phase}.txt').open('w') as out:r=subprocess.run(argv,cwd=W,stdout=out,stderr=subprocess.STDOUT)
   row['phases'].append({'phase':phase,'argv':argv,'exit':r.returncode,'seconds':time.time()-start,'production_sha256':sha(P.read_bytes())})
   assert (r.returncode==1 if phase=='red' else r.returncode==0),(case,phase,r.returncode)
   assert T.read_bytes()==caller
  row['restored_sha256']=sha(P.read_bytes());assert P.read_bytes()==original;rows.append(row)
finally:
 P.write_bytes(original);(E/'mutations.json').write_text(json.dumps({'pairs':rows,'original_sha256':sha(original),'restored_sha256':sha(P.read_bytes()),'test_sha256':sha(caller)},indent=2)+'\n')
print('actual production RED/restored GREEN',len(rows),'pairs')

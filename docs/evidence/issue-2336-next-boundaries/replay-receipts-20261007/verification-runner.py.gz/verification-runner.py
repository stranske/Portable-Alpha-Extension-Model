import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path.cwd()
evidence = root / "docs/evidence/issue-2336-next-boundaries"
output = evidence / "replay-receipts-20261007"
output.mkdir(exist_ok=False)
records = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def retain(name, data):
    (output / (name + ".gz")).write_bytes(gzip.compress(data, mtime=0))


def run(label, argv, cwd, passes, failures):
    junit = output / (label + ".xml")
    argv = [*argv, "--junitxml=" + str(junit)]
    started = time.monotonic()
    proc = subprocess.run(argv, cwd=cwd, capture_output=True, timeout=90)
    elapsed = time.monotonic() - started
    retain(label + ".stdout", proc.stdout)
    retain(label + ".stderr", proc.stderr)
    xml = junit.read_bytes()
    retain(label + ".xml", xml)
    junit.unlink()
    cases = ET.fromstring(xml).findall(".//testcase")
    counts = {
        tag: sum(case.find(tag) is not None for case in cases)
        for tag in ["failure", "error", "skipped"]
    }
    assert counts == {"failure": failures, "error": 0, "skipped": 0}, counts
    assert len(cases) == passes + failures
    assert proc.returncode == int(failures > 0), proc.stderr.decode()
    records.append(
        {
            "label": label,
            "argv": argv,
            "cwd": str(cwd),
            "exit": proc.returncode,
            "elapsed_seconds": elapsed,
            "passed": passes,
            **counts,
            "nodes": [[case.get("classname"), case.get("name")] for case in cases],
        }
    )
    print(label, counts, "passes", passes, flush=True)


replay = Path("docs/evidence/issue-2336-next-boundaries/replay.py")
test = Path("tests/test_cli_mutation_replay_isolation.py")
old_test = subprocess.check_output(["git", "show", "HEAD:" + str(test)])
new_test = (root / test).read_bytes()
driver = (root / replay).read_bytes()
cli = (root / "pa_core/cli.py").read_bytes()
anchor = b'controls["restored_sha256"] = digest(source.read_bytes())'
assert driver.count(anchor) == 1
receipt_mutant = driver.replace(anchor, b'controls["restored_sha256"] = digest(mutant)', 1)
output_anchor = b"    output.mkdir(parents=True, exist_ok=False)"
assert driver.count(output_anchor) == 1
output_mutant = driver.replace(
    output_anchor,
    b'    if output.exists():\n        shutil.rmtree(output / "phases", ignore_errors=True)\n'
    + output_anchor,
    1,
)
mutations = [
    (
        "receipt",
        receipt_mutant,
        "test_phase_failure_mutates_only_private_tree_and_preserves_active_source",
        2,
    ),
    (
        "nested-output",
        output_mutant,
        "test_existing_output_refused_before_copying_or_mutating_checkout",
        1,
    ),
]
for label, mutant, name, count in mutations:
    with tempfile.TemporaryDirectory(prefix="cli-receipt-control-") as temp:
        private = Path(temp)
        for relative in [replay, test, Path("pa_core/cli.py"), Path("tests/test_cli_observability_boundaries.py")]:
            target = private / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root / relative, target)
        node = str(test) + "::" + name
        argv = [sys.executable, "-m", "pytest", node, "-q", "-m", "not slow"]
        (private / replay).write_bytes(mutant)
        (private / test).write_bytes(old_test)
        run(label + "-previous", argv, private, count, 0)
        (private / test).write_bytes(new_test)
        run(label + "-red", argv, private, 0, count)
        (private / replay).write_bytes(driver)
        run(label + "-green", argv, private, count, 0)
        assert (private / replay).read_bytes() == driver

coverage_path = output / "focused-coverage.json"
argv = [
    sys.executable,
    "-m",
    "pytest",
    "tests/test_cli_observability_boundaries.py",
    "tests/test_cli_mutation_replay_isolation.py",
    "tests/test_cli_edge_cases.py",
    "tests/test_cli_packet_diff.py",
    "tests/test_cli_exception_handling.py",
    "-q",
    "-m",
    "not slow",
    "--cov=pa_core.cli",
    "--cov-report=term-missing",
    "--cov-report=json:" + str(coverage_path),
]
run("related", argv, root, 31, 0)
coverage = json.loads(coverage_path.read_bytes())
cli_coverage = coverage["files"]["pa_core/cli.py"]["summary"]
retain("focused-coverage.json", coverage_path.read_bytes())
coverage_path.unlink()
assert (root / replay).read_bytes() == driver
assert (root / "pa_core/cli.py").read_bytes() == cli
history = json.loads(Path("/tmp/cli-boundaries-history-verification.json").read_text())
retain("manifest-before-receipts.json", (evidence / "manifest.json").read_bytes())
retain("verification-runner.py", Path(__file__).read_bytes())
verification = {
    "records": records,
    "history": history,
    "targeted_cli_coverage": cli_coverage,
    "sha256": {"production": digest(cli), "driver": digest(driver), "previous_test": digest(old_test), "test": digest(new_test)},
    "mutation_controls": {label: digest(mutant) for label, mutant, _, _ in mutations},
    "pr_body_update": "Connector requires approval; approval policy is never. Remote body unchanged.",
}
(output / "verification.json").write_text(json.dumps(verification, indent=2) + "\n")
print("Targeted CLI coverage:", cli_coverage, flush=True)

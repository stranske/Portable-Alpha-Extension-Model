import gzip
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path.cwd()
out = root / 'docs/evidence/issue-2336-next-boundaries/json-precision-20261007'
source = root / 'pa_core/cli.py'
test = root / 'tests/test_cli_observability_boundaries.py'
original_source = source.read_bytes()
strengthened_test = test.read_bytes()
old_test = subprocess.check_output(['git', 'show', 'HEAD:tests/test_cli_observability_boundaries.py'])
anchor = b'datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat()'
replacement = b'datetime.fromtimestamp(int(record.created), tz=timezone.utc).isoformat()'
assert original_source.count(anchor) == 1
node = 'tests/test_cli_observability_boundaries.py::test_json_formatter_preserves_utc_and_interpolates_arguments'
phases = []

def run(phase, expected_exit, expected_failures):
    argv = [sys.executable, '/tmp/cli-json-capture.py', phase, sys.executable, '-m', 'pytest', node, '-q', '-m', 'not slow and not live_llm', f'--junitxml={out / (phase + ".xml")}']
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=130)
    print(result.stdout.decode(errors='replace'))
    assert result.returncode == expected_exit
    cases = ET.fromstring(gzip.decompress((out / f'{phase}.xml.gz').read_bytes())).findall('.//testcase')
    assert len(cases) == 1
    assert cases[0].get('name') == node.split('::')[1]
    assert len(cases[0].findall('failure')) == expected_failures
    assert not cases[0].findall('error') and not cases[0].findall('skipped')
    phases.append({'phase': phase, 'exit_code': expected_exit, 'failures': expected_failures, 'errors': 0, 'skips': 0})

try:
    source.write_bytes(original_source.replace(anchor, replacement))
    test.write_bytes(old_test)
    run('old-test-mutant-green', 0, 0)
    test.write_bytes(strengthened_test)
    run('strengthened-mutant-red', 1, 1)
    source.write_bytes(original_source)
    run('restored-green', 0, 0)
finally:
    source.write_bytes(original_source)
    test.write_bytes(strengthened_test)
    restored = source.read_bytes() == original_source
    controls = {
        'node': node,
        'before': anchor.decode(),
        'after': replacement.decode(),
        'source_sha256': hashlib.sha256(original_source).hexdigest(),
        'mutant_sha256': hashlib.sha256(original_source.replace(anchor, replacement)).hexdigest(),
        'old_test_sha256': hashlib.sha256(old_test).hexdigest(),
        'strengthened_test_sha256': hashlib.sha256(strengthened_test).hexdigest(),
        'restored_source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'byte_identical_restoration': restored,
        'phases': phases,
    }
    (out / 'precision-mutation.json').write_text(json.dumps(controls, indent=2) + '\n')
    assert restored

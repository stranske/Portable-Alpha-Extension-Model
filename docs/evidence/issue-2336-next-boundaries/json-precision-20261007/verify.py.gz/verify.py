import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path.cwd()
evidence = root / 'docs/evidence/issue-2336-next-boundaries'
out = evidence / 'json-precision-20261007'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)

def junit(path):
    data = path.read_bytes()
    cases = ET.fromstring(gzip.decompress(data)).findall('.//testcase')
    names = {(c.get('classname'), c.get('name')) for c in cases}
    assert len(names) == len(cases)
    counts = {tag: sum(c.find(tag) is not None for c in cases) for tag in ('failure', 'error', 'skipped')}
    counts['passed'] = len(cases) - sum(counts.values())
    return names, counts

verified_manifests = []
for directory, commit, relative_root in [
    (evidence, '3b934060', root),
    (evidence / 'recheck-20261007', '98fbf8ba', evidence / 'recheck-20261007'),
]:
    manifest = read_json(directory / 'manifest.json')
    for entry in manifest['files']:
        path = relative_root / entry['path']
        data = path.read_bytes()
        if path == root / 'tests/test_cli_observability_boundaries.py':
            data = subprocess.check_output(['git', 'show', f'{commit}:tests/test_cli_observability_boundaries.py'])
        assert digest(data) == entry['sha256'], path
        if 'decoded_sha256' in entry:
            assert digest(gzip.decompress(data)) == entry['decoded_sha256'], path
    verified_manifests.append({'manifest': str(directory.relative_to(root) / 'manifest.json'), 'entries': len(manifest['files']), 'historical_test_commit': commit})

comparison = read_json(evidence / 'comparison.json')
base = read_json(evidence / 'baseline-coverage.json.gz')
candidate = read_json(evidence / 'candidate-coverage.json.gz')
assert base['totals'] == comparison['baseline']
assert candidate['totals'] == comparison['candidate']
assert base['files'].keys() == candidate['files'].keys()
assert len(base['files']) == 186
for name, before in base['files'].items():
    after = candidate['files'][name]
    assert before['summary']['num_statements'] == after['summary']['num_statements']
    assert before['excluded_lines'] == after['excluded_lines']
    assert set(before['executed_lines']) <= set(after['executed_lines']), name
assert candidate['totals']['covered_lines'] - base['totals']['covered_lines'] == 7
historical_base_names, historical_base_counts = junit(evidence / 'baseline-junit.xml.gz')
historical_names, historical_counts = junit(evidence / 'candidate-junit.xml.gz')
assert historical_base_counts == {'passed': 1594, 'failure': 0, 'error': 0, 'skipped': 1}
assert historical_counts == {'passed': 1602, 'failure': 0, 'error': 0, 'skipped': 1}
assert historical_base_names <= historical_names
assert historical_names - historical_base_names == {tuple(n) for n in comparison['new_cases']}
for phase in ('baseline', 'candidate'):
    assert read_json(evidence / f'{phase}-process.json')['exit'] == 0

controls = read_json(evidence / 'mutation-final/controls.json')
assert len(controls['cases']) == 8
for case in controls['cases']:
    assert [p['phase'] for p in case['phases']] == ['red', 'green']
    for phase in case['phases']:
        names, counts = junit(evidence / 'mutation-final' / (phase['junit'] + '.gz'))
        assert len(names) == 1 and next(iter(names))[1] == case['node'].split('::')[1]
        red = phase['phase'] == 'red'
        assert counts == {'passed': int(not red), 'failure': int(red), 'error': 0, 'skipped': 0}
        assert phase['exit'] == int(red)
        assert phase['source_sha256'] == (case['mutant_sha256'] if red else controls['source_sha256'])

before_names, before_counts = junit(out / 'baseline-related.xml.gz')
after_names, after_counts = junit(out / 'candidate-related.xml.gz')
assert before_names == after_names
assert before_counts == after_counts == {'passed': 27, 'failure': 0, 'error': 0, 'skipped': 0}
related_base = read_json(out / 'baseline-related.coverage.json.gz')
related_candidate = read_json(out / 'candidate-related.coverage.json.gz')
assert related_base['totals'] == related_candidate['totals']
assert related_base['files']['pa_core/cli.py']['executed_lines'] == related_candidate['files']['pa_core/cli.py']['executed_lines']
focused_names, focused_counts = junit(out / 'focused.xml.gz')
assert focused_counts == {'passed': 8, 'failure': 0, 'error': 0, 'skipped': 0}
assert focused_names == {tuple(n) for n in comparison['new_cases']}
base_source = subprocess.check_output(['git', 'show', f"{comparison['base']}:pa_core/cli.py"])
assert (root / 'pa_core/cli.py').read_bytes() == base_source
for phase in ('baseline-related', 'candidate-related', 'focused', 'black-gate', 'ruff'):
    assert read_json(out / f'{phase}.json')['exit_code'] == 0
receipt = {
    'historical_manifests_verified': verified_manifests,
    'historical_baseline': historical_base_counts,
    'historical_candidate': historical_counts,
    'historical_covered_statements': [base['totals']['covered_lines'], candidate['totals']['covered_lines']],
    'historical_statements': base['totals']['num_statements'],
    'historical_excluded_lines': base['totals']['excluded_lines'],
    'historical_source_files': len(base['files']),
    'historical_mutation_pairs_verified': len(controls['cases']),
    'historical_no_executed_line_regression': True,
    'current_related_baseline': before_counts,
    'current_related_candidate': after_counts,
    'current_related_coverage': related_candidate['totals'],
    'current_related_same_named_cases_and_executed_lines': True,
    'current_focused': focused_counts,
    'source_matches_base': True,
    'source_sha256': digest(base_source),
    'test_sha256': digest((root / 'tests/test_cli_observability_boundaries.py').read_bytes()),
    'current_full_suite_rerun': False,
}
(out / 'verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))

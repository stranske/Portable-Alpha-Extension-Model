import gzip
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd()
out = root / 'docs/evidence/issue-2336-next-boundaries/json-precision-20261007'
phase = sys.argv[1]
argv = sys.argv[2:]
assert not (out / f'{phase}.json').exists()
started = time.monotonic()
result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
(out / f'{phase}.txt.gz').write_bytes(gzip.compress(result.stdout, mtime=0))
receipt = {
    'argv': argv,
    'cwd': str(root),
    'python': sys.version,
    'exit_code': result.returncode,
    'elapsed_seconds': time.monotonic() - started,
    'source_sha256': hashlib.sha256((root / 'pa_core/cli.py').read_bytes()).hexdigest(),
    'test_sha256': hashlib.sha256((root / 'tests/test_cli_observability_boundaries.py').read_bytes()).hexdigest(),
}
for suffix in ('xml', 'coverage.json'):
    path = out / f'{phase}.{suffix}'
    if path.exists():
        path.with_name(path.name + '.gz').write_bytes(gzip.compress(path.read_bytes(), mtime=0))
        path.unlink()
(out / f'{phase}.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(result.stdout.decode(errors='replace'))
print(json.dumps(receipt, indent=2))
sys.exit(result.returncode)

import hashlib
import json
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path.cwd()
output = Path("/tmp/cli-boundary-recheck/reinstall-mutation")
output.mkdir(exist_ok=False)
source = root / "pa_core/cli.py"
test = root / "tests/test_cli_observability_boundaries.py"
original_source = source.read_bytes()
new_test = test.read_bytes()
old_test = subprocess.run(
    ["git", "show", "3b934060:tests/test_cli_observability_boundaries.py"],
    capture_output=True, check=True,
).stdout
before = "        self._installed = False\n        if self._handler is not None:\n"
after = "        if self._handler is not None:\n"
text = original_source.decode()
assert text.count(before) == 1
mutant = text.replace(before, after, 1).encode()
node = "tests/test_cli_observability_boundaries.py::test_warning_collector_double_install_captures_once_and_restores"
digest = lambda data: hashlib.sha256(data).hexdigest()
controls = {"node": node, "before": before, "after": after, "phases": []}
try:
    for phase, source_bytes, test_bytes, expected in [
        ("old-test-green", mutant, old_test, 0),
        ("new-test-red", mutant, new_test, 1),
        ("new-test-restored-green", original_source, new_test, 0),
    ]:
        source.write_bytes(source_bytes)
        test.write_bytes(test_bytes)
        for path, prefix in [(source, "cli"), (test, "test_cli_observability_boundaries")]:
            for cache in (path.parent / "__pycache__").glob(prefix + ".*.pyc"):
                cache.unlink()
        junit = output / (phase + ".xml")
        argv = [sys.executable, "-m", "pytest", node, "-q", "-m", "not slow and not live_llm", "--junitxml=" + str(junit)]
        started = time.monotonic()
        with (output / (phase + ".txt")).open("x") as stream:
            result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT, timeout=90, check=False)
        controls["phases"].append({"phase": phase, "argv": argv, "cwd": str(root), "exit": result.returncode, "elapsed_seconds": time.monotonic() - started, "source_sha256": digest(source.read_bytes()), "test_sha256": digest(test.read_bytes()), "console": phase + ".txt", "junit": phase + ".xml"})
        nodes = ET.parse(junit).getroot().findall(".//testcase")
        assert len(nodes) == 1 and nodes[0].get("name") == node.split("::")[1]
        assert nodes[0].find("error") is None and nodes[0].find("skipped") is None
        assert (nodes[0].find("failure") is not None) == (expected == 1)
        assert result.returncode == expected
finally:
    source.write_bytes(original_source)
    test.write_bytes(new_test)
    for path, prefix in [(source, "cli"), (test, "test_cli_observability_boundaries")]:
        for cache in (path.parent / "__pycache__").glob(prefix + ".*.pyc"):
            cache.unlink()
    controls["restored_source_sha256"] = digest(source.read_bytes())
    controls["restored_test_sha256"] = digest(test.read_bytes())
    (output / "controls.json").write_text(json.dumps(controls, indent=2) + "\n")
assert source.read_bytes() == original_source and test.read_bytes() == new_test
print("Old test missed broken reinstallation; strengthened test fails; restored production passes")

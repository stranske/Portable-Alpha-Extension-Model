import faulthandler
import sys
import black

faulthandler.dump_traceback_later(20, exit=True)
sys.argv = ["black", "--check", "--verbose", "--line-length", "100", "--exclude", r"(\.workflows-lib|node_modules)", "."]
black.patched_main()

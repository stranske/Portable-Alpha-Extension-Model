import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

output = Path(sys.argv[1])
output.parent.mkdir(parents=True, exist_ok=True)
root = Path.cwd()
argv = sys.argv[2:]
started = time.monotonic()
with output.with_suffix(".txt").open("x") as stream:
    result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT, check=False, timeout=180)
receipt = {
    "argv": argv,
    "cwd": str(root),
    "exit": result.returncode,
    "elapsed_seconds": time.monotonic() - started,
    "python": sys.version,
    "hashes": {
        str(path): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in [Path("pa_core/cli.py"), Path("tests/test_cli_observability_boundaries.py")]
    },
}
output.with_suffix(".json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
sys.exit(result.returncode)
